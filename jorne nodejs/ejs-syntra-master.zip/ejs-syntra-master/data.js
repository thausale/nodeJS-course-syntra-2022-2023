const todos = [
  {
    id: 'dfbhjgfghghiudq',
    title: 'Learn Node.js',
    completed: true,
    email: 'test@jsjj.be',
  },
  {
    id: 'zaerezrcsvvref',
    title: 'Learn Express.js',
    completed: false,
    email: 'test@jsjj.be',
  },
  {
    id: 'tekgjkjhkhertretgf',
    title: 'Learn MongoDB',
    completed: false,
    email: 'test@jsjj.be',
  },
];

const info = {
  pageTitle: 'About',
  name: 'John Doe',
  age: 30,
  phone: '123-456-7890',
};

export { todos, info };
